from ast import Delete, If
from ctypes.wintypes import PINT
from distutils.command.clean import clean
from distutils.util import execute
from msilib.schema import SelfReg
import os
from tkinter import E
from typing_extensions import Self
import requests, colorama
import random
import string
import time
import ctypes
import sys
from colorama import Fore
from turtle import clear
import discord_rpc
colorama.init()




try: 
    from discord_webhook import DiscordWebhook
except ImportError: 
    input(f"Module discord_webhook not installed, to install run '{'py -3' if os.name == 'nt' else 'python3.8'} -m pip install discord_webhook'\nPress enter to exit") 
    exit()  

try: 
    import requests 
except ImportError: 
    input(f"Module requests not installed, to install run '{'py -3' if os.name == 'nt' else 'python3.8'} -m pip install requests'\nPress enter to exit")# Tell the user it has not been installed and how to install it
    exit() 


def main(self):
        os.system('cls' if os.name == 'nt' else 'clear') 
        if os.name == "nt":
            print("")
            ctypes.windll.kernel32.SetConsoleTitleW("WebHook Spammer - Made by Bac") 
        else: 
            print(f'\33]0"WebHook Spammer - Made by Bac\a', end='', flush=True) 

animation = ["[■□□□□□□□□□]","[■■□□□□□□□□]", "[■■■□□□□□□□]", "[■■■■□□□□□□]", "[■■■■■□□□□□]", "[■■■■■■□□□□]", "[■■■■■■■□□□]", "[■■■■■■■■□□]", "[■■■■■■■■■□]", "[■■■■■■■■■■]"]

for i in range(len(animation)):
   time.sleep(0.2)
   sys.stdout.write("\r" + animation[i % len(animation)])
   sys.stdout.flush()
print("")


print("\n")
time.sleep(2)
os.system('cls' if os.name == 'nt' else 'clear')

print(f"{Fore.LIGHTRED_EX}                                             ")
time.sleep(0.2)
print(f"*@@@***@@m           @@             mm@***@m@")
time.sleep(0.2)
print(f"@@    @@          m@@m          m@@*     *@")
time.sleep(0.2)
print(f"@@    @@         m@*@@!         @@*       *")
time.sleep(0.2)
print(f"@@***@mm        m@  *@@         @@")
time.sleep(0.2)
print(f"@!    *@        @@@!@!@@        @!m")
time.sleep(0.2)
print(f"!!    m@       !*      @@       *!@m     m*")
time.sleep(0.2)
print(f"!:    *!        !!!!@!!@        !!!     ")
time.sleep(0.2)
print(f"!:    !!       !*      !!       :!!:     !*")
time.sleep(0.2)
print(f": !: : : :     : : :   : :::        : : : :!")
time.sleep(0.2)
print(f"")


print(f""+ Fore.RESET)


print(f"{Fore.MAGENTA}[1]{Fore.WHITE} WebHook Writer")
print(f"{Fore.MAGENTA}[2]{Fore.WHITE} WebHook Spammer")
print(f"{Fore.MAGENTA}[3]{Fore.WHITE} Dual WebHook Spammer")
print(f"{Fore.MAGENTA}[4]{Fore.WHITE} Triple Webhook Spammer")
print(f"{Fore.MAGENTA}[5]{Fore.WHITE} Quad WenHook Spammer")
print(f""+ Fore.RESET)
print(f"{Fore.MAGENTA}")
num4 = int(input(f""))
print(f""+ Fore.RESET)

a = 1
b = 2
c = 3
d = 4
e = 5

if num4 == 1:
 time.sleep(0.2)
 num1 = input("webhook: ")  
 time.sleep(0.2)
 num2 = input(f"content: ")


 DiscordWebhook( 
              url = num1,
           content = num2
         ).execute()
else:
 if num4 == 2:
  time.sleep(0.2)
  num1 = input("webhook: ")  
  time.sleep(0.2)
  num2 = input(f"content: ")
  time.sleep(0.2)
  num = int(input("repeat: "))
         
  for i in range(num):
     DiscordWebhook( 
          url = num1,
      content = num2
     ).execute()
 else:
  if num4 == 3:
      time.sleep(0.2)
      num1 = input("webhook: ")
      time.sleep(0.2)
      num5 = input("webhook2: ")
      time.sleep(0.2)
      num2 = input(f"content: ")
      time.sleep(0.2)
      
      num = int(input("repeat: "))
         
      for i in range(num):
          DiscordWebhook( 
                url = num1,
             content = num2
             ).execute()
          DiscordWebhook( 
                url = num5,
            content = num2
            ).execute()
  else:
        if num4 ==4:
         time.sleep(0.2)
         num1 = input("webhook: ")
         time.sleep(0.2)
         num5 = input("webhook2: ")
         time.sleep(0.2)
         num6 = input("webhook3: ")
         time.sleep(0.2)
         num2 = input(f"content: ")
         time.sleep(0.2)
         
         num = int(input("repeat: "))
         
         for i in range(num):
             DiscordWebhook( 
                  url = num1,
               content = num2
             ).execute()
             DiscordWebhook( 
                  url = num5,
               content = num2
             ).execute()
             DiscordWebhook( 
                  url = num6,
               content = num2
             ).execute()
        else:
          if num4 == 5:
             time.sleep(0.2)
             num1 = input("webhook1: ")
             time.sleep(0.2)
             num5 = input("webhook2: ")
             time.sleep(0.2)
             num6 = input("webhook3: ")
             time.sleep(0.2)
             num7 = input("webhook4: ")
             time.sleep(0.2)
             num2 = input(f"content: ")
             time.sleep(0.2)
         
             num = int(input("repeat: "))
          
             for i in range(num):
                DiscordWebhook( 
                     url = num1,
                  content = num2
                ).execute()
                DiscordWebhook( 
                     url = num5,
                  content = num2
                 ).execute()
                DiscordWebhook( 
                     url = num6,
                  content = num2
                ).execute()
                DiscordWebhook( 
                     url = num7,
                  content = num2
                ).execute()
input("\nThe end! Press Enter 5 times to close the program.") 
[input(i) for i in range(4,0,-1)]        
      
 

         
            


       
 
